#include <zephyr/kernel.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/l2cap.h>
#include <zephyr/logging/log.h>

LOG_MODULE_REGISTER(l2cap_server);

#define DATA_MTU 498  // Match your L2CAP_TX_MTU

NET_BUF_POOL_FIXED_DEFINE(tx_pool,10,                           // Number of buffers
                          BT_L2CAP_SDU_BUF_SIZE(DATA_MTU),      // Size per buffer
                          CONFIG_BT_CONN_TX_USER_DATA_SIZE,     // User data size
                          NULL);                               // Destroy callback


#define PSM 0x0080  // Custom PSM for your application
#define PAYLOAD_SIZE 200  // Test payload size

static struct bt_conn *default_conn;
static struct bt_l2cap_le_chan l2cap_chan;
static bool channel_connected = false;



// L2CAP Channel Callbacks
static int l2cap_recv(struct bt_l2cap_chan *chan, struct net_buf *buf)
{
    LOG_INF("Received %d bytes", buf->len);
    // Process incoming data (if needed for bidirectional)
    return 0;
}

static void l2cap_sent(struct bt_l2cap_chan *chan)
{
    LOG_DBG("Data sent, credits replenished");
}

static void l2cap_connected(struct bt_l2cap_chan *chan)
{
    struct bt_l2cap_le_chan *le_chan = CONTAINER_OF(chan, 
                                       struct bt_l2cap_le_chan, chan);
    
    LOG_INF("L2CAP connected: MTU %d, MPS %d", 
            le_chan->tx.mtu, le_chan->tx.mps);
    channel_connected = true;
}

static void l2cap_disconnected(struct bt_l2cap_chan *chan)
{
    LOG_INF("L2CAP disconnected");
    channel_connected = false;
}

static struct bt_l2cap_chan_ops l2cap_ops = {
    .recv = l2cap_recv,
    .sent = l2cap_sent,
    .connected = l2cap_connected,
    .disconnected = l2cap_disconnected,
};

// Accept incoming L2CAP connection requests
static int l2cap_accept(struct bt_conn *conn, struct bt_l2cap_server *server,
                        struct bt_l2cap_chan **chan)
{
    LOG_INF("Incoming L2CAP connection request");
    
    memset(&l2cap_chan, 0, sizeof(l2cap_chan));
    l2cap_chan.chan.ops = &l2cap_ops;
    l2cap_chan.rx.mtu = 498;  // Maximum receive MTU
    
    *chan = &l2cap_chan.chan;
    return 0;
}

static struct bt_l2cap_server l2cap_server = {
    .psm = PSM,
    .sec_level = BT_SECURITY_L1,  // No pairing required for testing
    .accept = l2cap_accept,
};

// BLE Connection Callbacks
static void connected(struct bt_conn *conn, uint8_t err)
{
    if (err) {
        LOG_ERR("Connection failed (err %u)", err);
        return;
    }
    
    default_conn = bt_conn_ref(conn);
    LOG_INF("BLE Connected");
    
    // Update to 2M PHY for higher throughput
    int ret = bt_conn_le_phy_update(conn, BT_CONN_LE_PHY_PARAM_2M);
    if (ret) {
        LOG_WRN("PHY update failed (err %d)", ret);
    }
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
    LOG_INF("BLE Disconnected (reason %u)", reason);
    
    if (default_conn) {
        bt_conn_unref(default_conn);
        default_conn = NULL;
    }
}

static struct bt_conn_cb conn_callbacks = {
    .connected = connected,
    .disconnected = disconnected,
};

// Advertisement data
static const struct bt_data ad[] = {
    BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
    BT_DATA_BYTES(BT_DATA_UUID16_ALL, 0x0f, 0x18),  // Battery Service UUID
};

// Send test data continuously
static void send_data_thread(void)
{
    uint8_t test_data[PAYLOAD_SIZE];
    uint32_t packet_count = 0;
    int64_t start_time, end_time;
    uint32_t total_bytes = 0;
    
    // Fill with incrementing pattern for verification
    for (int i = 0; i < PAYLOAD_SIZE; i++) {
        test_data[i] = i & 0xFF;
    }
    
    LOG_INF("Starting data transmission thread");
    
    start_time = k_uptime_get();
    
    while (1) {
        if (channel_connected && default_conn) {
            struct net_buf *buf = net_buf_alloc(&tx_pool, K_NO_WAIT);
            if (!buf) {
                LOG_ERR("Failed to allocate buffer");
                k_sleep(K_MSEC(10));
                continue;
            }
            
            // Add packet counter at start for debugging
            net_buf_add_le32(buf, packet_count);
            net_buf_add_mem(buf, test_data, PAYLOAD_SIZE - 4);
            
            int ret = bt_l2cap_chan_send(&l2cap_chan.chan, buf);
            if (ret < 0) {
                LOG_ERR("Send failed (err %d)", ret);
                net_buf_unref(buf);
                k_sleep(K_MSEC(10));
            } else {
                packet_count++;
                total_bytes += PAYLOAD_SIZE;
                
                // Calculate throughput every 1000 packets
                if (packet_count % 1000 == 0) {
                    end_time = k_uptime_get();
                    int64_t elapsed_ms = end_time - start_time;
                    if (elapsed_ms > 0) {
                        uint32_t throughput_kbps = 
                            (total_bytes * 8) / elapsed_ms;
                        LOG_INF("Packets: %u, Throughput: %u kbps", 
                                packet_count, throughput_kbps);
                    }
                    start_time = end_time;
                    total_bytes = 0;
                }
            }
        } else {
            k_sleep(K_MSEC(100));
        }
        
        // Small delay to avoid flooding
        k_sleep(K_MSEC(1));
    }
}

K_THREAD_DEFINE(tx_thread, 2048, send_data_thread, NULL, NULL, NULL, 7, 0, 0);

int main(void)
{
    int err;
    
    LOG_INF("L2CAP Throughput Test - Peripheral");
    
    // Initialize BLE
    err = bt_enable(NULL);
    if (err) {
        LOG_ERR("Bluetooth init failed (err %d)", err);
        return 0;
    }
    
    LOG_INF("Bluetooth initialized");
    
    // Register connection callbacks
    bt_conn_cb_register(&conn_callbacks);
    
    // Register L2CAP server
    err = bt_l2cap_server_register(&l2cap_server);
    if (err) {
        LOG_ERR("L2CAP server registration failed (err %d)", err);
        return 0;
    }
    
    LOG_INF("L2CAP server registered on PSM 0x%04x", PSM);
    
    // Start advertising
    err = bt_le_adv_start(BT_LE_ADV_CONN_FAST_1, ad, ARRAY_SIZE(ad), NULL, 0);
    if (err) {
        LOG_ERR("Advertising failed (err %d)", err);
        return 0;
    }
    
    LOG_INF("Advertising started");
    
    return 0;
}
